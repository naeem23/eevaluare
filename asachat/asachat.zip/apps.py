from django.apps import AppConfig


class AsachatConfig(AppConfig):
    name = 'asachat'
